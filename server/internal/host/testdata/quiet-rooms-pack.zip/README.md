# Quiet Rooms Studio

Svelte 5 + Vite + Tailwind CSS 4 page exported from BuildY.

```sh
npm i && npm run dev
```

`npm run build` writes the static site to `dist/`.

- `src/App.svelte` composes the sections in `src/sections/`; each section is one UI8Kit registry block with its props.
- Everything else under `src/` (blocks, components, compose, kit, icons, utils, styles, presets) and
  `ui8kit.config.json` / `ui8kit.lock.json` are exactly what `npx ui8kit init` + `npx ui8kit add` write for
  the items in `GENERATOR.json` (`registryItems`). Check them with `npx ui8kit check`; do not edit them.
- Dark theme: `class="dark"` or `data-theme="dark"` on `<html>`.
