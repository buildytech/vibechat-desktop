import { mount } from "svelte";
// The registry's global CSS (ui8kit.config.json globalCss): theme tokens, kit CSS, Tailwind @source of src/.
import "./styles/index.css";
import App from "./App.svelte";

mount(App, { target: document.getElementById("app")! });
