<!-- team-simple / cards3: UI8Kit registry block (npx ui8kit add team-simple). -->
<script lang="ts">
	import TeamSimple from "../blocks/team-simple.svelte";

	const props = {
		"layout": "grid",
		"cols": "3",
		"surface": "cards",
		"members": [
			{
				"id": "anna",
				"title": "Anna Petrova",
				"description": "Lead designer"
			},
			{
				"id": "ilya",
				"title": "Ilya Sorokin",
				"description": "Plans and drawings"
			},
			{
				"id": "mira",
				"title": "Mira Kim",
				"description": "Materials and sourcing"
			}
		],
		"id": "team",
		"title": "The studio",
		"description": "Three people, one flat at a time."
	};
</script>

<TeamSimple {...props} />
