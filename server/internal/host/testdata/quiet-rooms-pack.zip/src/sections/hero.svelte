<!-- hero-simple / mediaEnd: UI8Kit registry block (npx ui8kit add hero-simple). -->
<script lang="ts">
	import HeroSimple from "../blocks/hero-simple.svelte";

	const props = {
		"media": "end",
		"ratio": "landscape",
		"id": "hero",
		"title": "Calm rooms for small flats",
		"badge": "Interior studio",
		"description": "We plan, pick materials and see the work through, so a 40 m² flat feels like more.",
		"image": "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=1200",
		"imageAlt": "A light living room with a sofa and plants",
		"actionLabel": "Book a call",
		"actionHref": "#contact"
	};
</script>

<HeroSimple {...props} />
