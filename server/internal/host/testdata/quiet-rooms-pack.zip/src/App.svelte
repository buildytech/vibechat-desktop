<!-- Quiet Rooms Studio (quiet-rooms): one registry block per section. -->
<script lang="ts">
	import Hero from "./sections/hero.svelte";
	import Team from "./sections/team.svelte";
</script>

<Hero />
<Team />
