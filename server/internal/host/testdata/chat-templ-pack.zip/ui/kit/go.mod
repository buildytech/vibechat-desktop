module github.com/ui8kit/codegen/generated/templ

go 1.26.0

require github.com/a-h/templ v0.3.1070
